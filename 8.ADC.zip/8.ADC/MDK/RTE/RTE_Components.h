
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'gpio' 
 * Target:  'Target 1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_DEVICE_STDPERIPHERALS_ADC
#define RTE_DEVICE_STDPERIPHERALS_EXTI
#define RTE_DEVICE_STDPERIPHERALS_FMC
#define RTE_DEVICE_STDPERIPHERALS_GPIO
#define RTE_DEVICE_STDPERIPHERALS_MISC
#define RTE_DEVICE_STDPERIPHERALS_PMU
#define RTE_DEVICE_STDPERIPHERALS_RCU
#define RTE_DEVICE_STDPERIPHERALS_TIMER
#define RTE_DEVICE_STDPERIPHERALS_USART

#endif /* RTE_COMPONENTS_H */
