#ifndef __ADC__
#define __ADC__
	
#ifdef __cplusplus
extern "C"{
#endif
#include <stdio.h>
#include "gd32f30x.h"
#include "gd32f30x_fmc.h"

#ifdef __cplusplus
}
#endif

#endif
