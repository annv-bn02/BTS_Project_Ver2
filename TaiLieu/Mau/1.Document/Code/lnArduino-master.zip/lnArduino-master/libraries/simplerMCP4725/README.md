This is a simpler version of adafruit MCP4725
The main change is that you can provide the i2c interface to use
