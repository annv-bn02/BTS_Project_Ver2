tinyusb has been duplicated as the original project is way too big due to all its submodule
There is only one patch applied

commit id = 9c8c5c1
