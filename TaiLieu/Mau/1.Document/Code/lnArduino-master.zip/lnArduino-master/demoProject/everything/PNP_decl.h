#define PNP_width 48
#define PNP_height 48
extern const unsigned char PNP[];
