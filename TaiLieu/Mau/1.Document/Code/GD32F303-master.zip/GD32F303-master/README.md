# CMSIS-FreeRTOS Example

CMSIS-RTOS2 Doc : file:///C:/Keil_Packs/ARM/CMSIS/5.6.0/CMSIS/Documentation/RTOS2/html/index.html

CMSIS-FreeRTOS Doc : file:///C:/Keil_Packs/ARM/CMSIS-FreeRTOS/10.3.0/CMSIS/Documentation/General/html/index.html

` C:/Keil_Packs/ ` : Your keil Packs addr. 

